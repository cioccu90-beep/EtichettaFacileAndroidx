package it.etichettafacile.app.ocr

data class Fields(val lot: String = "", val expiry: String = "", val brand: String = "", val ingredients: String = "")

object ConservativeParser {
    fun parse(text: String): Fields {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        fun find(pattern: Regex): String = lines.firstNotNullOfOrNull { pattern.find(it)?.groupValues?.getOrNull(1)?.trim() }.orEmpty()
        return Fields(
            lot = find(Regex("""(?i)(?:LOTTO|LOT|BATCH)\s*[:#\-]?\s*([A-Z0-9./-]{3,20})""")),
            expiry = find(Regex("""(?i)(?:SCADENZA|SCAD|EXP|DA CONSUMARSI PREFERIBILMENTE ENTRO)\s*[:.]?\s*(\d{1,2}[/. -]\d{1,2}[/. -]\d{2,4}|\d{4}[/. -]\d{1,2}[/. -]\d{1,2})""")),
            brand = find(Regex("""(?i)(?:PRODOTTO DA|CONFEZIONATO DA|FABBRICATO DA)\s*[:\-]?\s*(.+)""")),
            ingredients = find(Regex("""(?i)(?:INGREDIENTI|INGR\.?)\s*[:\-]\s*(.+)"""))
        )
    }
}
