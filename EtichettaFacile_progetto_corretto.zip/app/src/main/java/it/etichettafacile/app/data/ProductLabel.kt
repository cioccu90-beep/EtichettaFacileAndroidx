package it.etichettafacile.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "labels")
data class ProductLabel(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productName: String = "",
    val brand: String = "",
    val lot: String = "",
    val expiry: String = "",
    val ingredients: String = "",
    val openingDate: String = "",
    val storage: String = "",
    val originalPhotoUri: String = "",
    val rawOcrText: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
