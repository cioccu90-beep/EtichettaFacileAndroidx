package it.etichettafacile.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LabelDao {
    @Query("SELECT * FROM labels ORDER BY updatedAt DESC")
    fun all(): Flow<List<ProductLabel>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(label: ProductLabel): Long
    @Query("DELETE FROM labels WHERE id = :id")
    suspend fun delete(id: Long)
}
