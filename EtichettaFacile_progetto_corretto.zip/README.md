# Etichetta Facile — progetto aggiornato

Questa versione elimina l'OCR/AI dal flusso e aggiunge:
- scatto diretto con la fotocamera Android;
- scelta di una foto già esistente dalla galleria;
- scelta iniziale: originale, operativa o entrambe;
- scelta per la copia originale: così com'è o migliorata;
- regolazione di contrasto e luminosità applicata soltanto all'anteprima della copia, senza modificare il file originale;
- compilazione manuale dei campi dell'etichetta operativa.

Nota: la stampa effettiva e l'integrazione Bluetooth con stampanti specifiche non sono ancora implementate/verificate. Questo è il codice sorgente aggiornato, non un APK già compilato.
