package it.etichettafacile.app

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Base64
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.print.pdf.PrintedPdfDocument
import android.graphics.pdf.PdfDocument
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import it.etichettafacile.app.data.AppDatabase
import it.etichettafacile.app.data.ProductLabel
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private var pendingCameraFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent {
            MaterialTheme {
                var product by remember { mutableStateOf("") }
                var brand by remember { mutableStateOf("") }
                var lot by remember { mutableStateOf("") }
                var expiry by remember { mutableStateOf("") }
                var ingredients by remember { mutableStateOf("") }
                var opening by remember { mutableStateOf("") }
                var storage by remember { mutableStateOf("") }
                var photoUri by remember { mutableStateOf<Uri?>(null) }
                var status by remember { mutableStateOf("Scegli cosa stampare e poi fotografa o importa l'etichetta.") }
                var selectedPrinter by remember { mutableStateOf("Seleziona stampante") }
                var selectedMode by remember { mutableStateOf("Entrambe") }
                var copyMode by remember { mutableStateOf("Migliorata") }
                var contrast by remember { mutableFloatStateOf(1.25f) }
                var brightness by remember { mutableFloatStateOf(1f) }
                var showEnhancement by remember { mutableStateOf(false) }
                val history by db.labels().all().collectAsState(initial = emptyList())

                val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
                    if (uri != null) {
                        photoUri = uri
                        showEnhancement = false
                        status = "Foto caricata. L'originale non viene modificato."
                    }
                }
                val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
                    val file = pendingCameraFile
                    if (ok && file != null && file.exists()) {
                        photoUri = Uri.fromFile(file)
                        showEnhancement = false
                        status = "Foto scattata. L'originale è conservato senza modifiche."
                    } else status = "Scatto annullato. Puoi riprovare o importare una foto."
                }

                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Etichetta Facile", style = MaterialTheme.typography.headlineMedium)
                    Text("Senza AI e senza OCR: la seconda etichetta si compila manualmente.")
                    Text("Stampante", style = MaterialTheme.typography.titleMedium)
                    var showPrinterMenu by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { showPrinterMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedPrinter) }
                        DropdownMenu(expanded = showPrinterMenu, onDismissRequest = { showPrinterMenu = false }) {
                            listOf("Phomemo M110", "NIIMBOT B21 Pro", "HaccpOK Print").forEach { printer ->
                                DropdownMenuItem(text = { Text(printer) }, onClick = {
                                    selectedPrinter = printer
                                    showPrinterMenu = false
                                    status = "Stampante selezionata: $printer. Per il collegamento, usa Associa stampante."
                                })
                            }
                        }
                    }
                    OutlinedButton(onClick = {
                        try {
                            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                            status = "Nelle impostazioni Bluetooth associa la stampante. Poi torna qui e premi Stampa."
                        } catch (e: Exception) { status = "Impossibile aprire le impostazioni Bluetooth." }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Associa stampante (Bluetooth)") }
                    Text("Nota: la selezione del modello non garantisce la compatibilità. La stampa dipende dal supporto Android o dall'app/driver del produttore.", style = MaterialTheme.typography.bodySmall)
                    Divider()
                    Text("1. Cosa vuoi stampare?", style = MaterialTheme.typography.titleMedium)
                    listOf("Originale", "Operativa", "Entrambe").forEach { option ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                            RadioButton(selected = selectedMode == option, onClick = { selectedMode = option })
                            Text(option, modifier = Modifier.padding(top = 12.dp))
                        }
                    }
                    Text("3. Foto dell'etichetta", style = MaterialTheme.typography.titleMedium)
                    Button(onClick = {
                        try {
                            val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: cacheDir
                            if (!dir.exists()) dir.mkdirs()
                            pendingCameraFile = File.createTempFile("etichetta_originale_", ".jpg", dir)
                            val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", pendingCameraFile!!)
                            cameraLauncher.launch(uri)
                        } catch (e: Exception) { status = "Non riesco ad aprire la fotocamera: ${e.message ?: "errore"}" }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Scatta una foto con la fotocamera") }
                    OutlinedButton(onClick = { photoPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("Scegli una foto già esistente") }


                    if (selectedMode != "Originale") {
                        Divider()
                        Text("Etichetta operativa — compilazione manuale", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(product, { product = it }, label = { Text("Prodotto") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(brand, { brand = it }, label = { Text("Produttore / marca") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(lot, { lot = it }, label = { Text("Lotto") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(expiry, { expiry = it }, label = { Text("Scadenza originale") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(ingredients, { ingredients = it }, label = { Text("Ingredienti / allergeni (da trascrivere e verificare)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        OutlinedTextField(opening, { opening = it }, label = { Text("Data di apertura") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(storage, { storage = it }, label = { Text("Conservazione") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            lifecycleScope.launch {
                                db.labels().save(ProductLabel(productName = product, brand = brand, lot = lot, expiry = expiry,
                                    ingredients = ingredients, openingDate = opening, storage = storage,
                                    originalPhotoUri = photoUri?.toString().orEmpty(), rawOcrText = ""))
                                status = "Scheda salvata nella cronologia locale."
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Salva scheda") }
                    }
                    if (selectedMode != "Operativa") {
                        Divider()
                        Text("Alla fine: come vuoi stampare la copia originale?", style = MaterialTheme.typography.titleMedium)
                        listOf("Così com'è", "Migliorata").forEach { option ->
                            Row(Modifier.fillMaxWidth()) {
                                RadioButton(selected = copyMode == option, onClick = { copyMode = option; showEnhancement = option == "Migliorata" })
                                Text(option, modifier = Modifier.padding(top = 12.dp))
                            }
                        }
                    }
                    val preview = remember(photoUri, contrast, brightness, copyMode) {
                        photoUri?.let { uri ->
                            try {
                                val input = if (uri.scheme == "file") File(uri.path!!).inputStream() else contentResolver.openInputStream(uri)
                                val bitmap = input?.use { BitmapFactory.decodeStream(it) }
                                if (bitmap != null && copyMode == "Migliorata") enhance(bitmap, contrast, brightness) else bitmap
                            } catch (_: Exception) { null }
                        }
                    }
                    if (preview != null) {
                        Text(if (copyMode == "Migliorata") "Anteprima della copia migliorata" else "Anteprima originale")
                        Image(bitmap = preview.asImageBitmap(), contentDescription = "Anteprima etichetta", modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp))
                        if (copyMode == "Migliorata" && selectedMode != "Operativa") {
                            Text("Contrasto")
                            Slider(value = contrast, onValueChange = { contrast = it }, valueRange = 0.8f..2.5f)
                            Text("Luminosità")
                            Slider(value = brightness, onValueChange = { brightness = it }, valueRange = 0.6f..1.5f)
                            Text("Le regolazioni si applicano solo alla copia: il file originale resta intatto.", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Button(onClick = {
                        if (selectedMode != "Operativa" && photoUri == null) {
                            status = "Per stampare l'originale, prima scatta o scegli una foto."
                        } else {
                            val html = buildString {
                                append("<html><head><meta charset='utf-8'><style>body{font-family:sans-serif;margin:12px} .page{page-break-after:always} img{max-width:100%;height:auto} h2{font-size:18px} p{font-size:14px;white-space:pre-wrap}</style></head><body>")
                                if (selectedMode != "Operativa" && photoUri != null) {
                                    try {
                                        val input = if (photoUri!!.scheme == "file") File(photoUri!!.path!!).inputStream() else contentResolver.openInputStream(photoUri!!)
                                        val bitmap = input?.use { BitmapFactory.decodeStream(it) }
                                        if (bitmap != null) {
                                            val chosen = if (copyMode == "Migliorata") enhance(bitmap, contrast, brightness) else bitmap
                                            val bytes = java.io.ByteArrayOutputStream().use { out -> chosen.compress(Bitmap.CompressFormat.JPEG, 95, out); out.toByteArray() }
                                            val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
                                            append("<div class='page'><h2>Etichetta originale</h2><img src='data:image/jpeg;base64,$encoded'></div>")
                                        }
                                    } catch (_: Exception) { }
                                }
                                if (selectedMode != "Originale") {
                                    append("<div><h2>Etichetta operativa</h2>")
                                    append("<p><b>Prodotto:</b> ${product.htmlEscape()}</p>")
                                    append("<p><b>Produttore / marca:</b> ${brand.htmlEscape()}</p>")
                                    append("<p><b>Lotto:</b> ${lot.htmlEscape()}</p>")
                                    append("<p><b>Scadenza originale:</b> ${expiry.htmlEscape()}</p>")
                                    append("<p><b>Ingredienti / allergeni:</b> ${ingredients.htmlEscape()}</p>")
                                    append("<p><b>Data di apertura:</b> ${opening.htmlEscape()}</p>")
                                    append("<p><b>Conservazione:</b> ${storage.htmlEscape()}</p></div>")
                                }
                                append("</body></html>")
                            }
                            printHtml(html, "Etichetta Facile - $selectedMode")
                            status = "Finestra di stampa Android aperta. Se la stampante non compare, potrebbe servire il driver/app del produttore."
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Stampa") }
                    Text(status)
                    Divider()
                    Text("Cronologia locale (${history.size})", style = MaterialTheme.typography.titleLarge)
                    history.forEach { item ->
                        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(item.productName.ifBlank { "Prodotto senza nome" }, style = MaterialTheme.typography.titleMedium)
                                Text("Lotto: ${item.lot.ifBlank { "—" }} • Scadenza: ${item.expiry.ifBlank { "—" }}")
                                TextButton(onClick = {
                                    product = item.productName; brand = item.brand; lot = item.lot; expiry = item.expiry
                                    ingredients = item.ingredients; opening = item.openingDate; storage = item.storage
                                    photoUri = item.originalPhotoUri.takeIf { it.isNotBlank() }?.let(Uri::parse)
                                    status = "Scheda caricata per modifica."
                                }) { Text("Apri / modifica") }
                            }
                        }
                    }
                    Text("La stampa usa il servizio di stampa Android. La compatibilità e il collegamento con ciascun modello vanno verificati con la stampante reale; potrebbe essere necessaria l'app del produttore.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    private fun printHtml(html: String, jobName: String) {
        val webView = WebView(this)
        webView.settings.defaultTextEncodingName = "UTF-8"
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                manager.print(jobName, view.createPrintDocumentAdapter(jobName), PrintAttributes.Builder().build())
            }
        }
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    private fun String.htmlEscape(): String =
        replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;")

    private fun enhance(source: Bitmap, contrast: Float, brightness: Float): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val matrix = ColorMatrix(floatArrayOf(
            contrast, 0f, 0f, 0f, (brightness - 1f) * 255f,
            0f, contrast, 0f, 0f, (brightness - 1f) * 255f,
            0f, 0f, contrast, 0f, (brightness - 1f) * 255f,
            0f, 0f, 0f, 1f, 0f
        ))
        paint.colorFilter = ColorMatrixColorFilter(matrix)
        Canvas(output).drawBitmap(source, 0f, 0f, paint)
        return output
    }
}
