# Etichetta Facile — progetto aggiornato

Questa cartella contiene il progetto Android completo. Include:
- scelta della stampante (Phomemo M110, NIIMBOT B21 Pro, HaccpOK Print);
- apertura delle impostazioni Bluetooth Android per associare una stampante;
- scelta di stampa: originale, operativa o entrambe (originale prima);
- acquisizione foto da fotocamera o galleria;
- compilazione manuale dell’etichetta operativa;
- cronologia locale delle schede.

La funzione di stampa usa il servizio di stampa Android. La selezione del modello e l’associazione Bluetooth non garantiscono che il dispositivo sia compatibile: la stampa con ciascun modello deve essere verificata con la stampante reale e può richiedere l’app o il driver del produttore.

La funzione OCR/AI non è inclusa. Il file MainActivity.kt contiene la correzione della sintassi nella funzione htmlEscape(). Il progetto non è dichiarato compilato o testato in questa consegna: eseguire il workflow GitHub Actions per verificarlo.
