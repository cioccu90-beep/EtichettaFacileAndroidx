# Etichetta Facile — progetto Android iniziale

Questa è una base di progetto Android Kotlin/Compose, creata per evitare di copiare manualmente molti frammenti dal Playground.

## Stato importante
- Non è stata eseguita una build Gradle in questo ambiente.
- Il workflow GitHub Actions è predisposto ma non è stato eseguito.
- Foto: consente di selezionare una foto e lanciare OCR, ma la persistenza duratura dell'immagine originale va completata/verificata.
- OCR: ML Kit Text Recognition on-device e parser conservativo per lotto, scadenza, produttore e ingredienti; verifica sempre i risultati.
- Database locale: Room, con cronologia e apertura/modifica/eliminazione delle schede.
- Stampa: la scelta Originale/Operativa/Entrambe è solo selezionabile in questa base; la stampa non è ancora implementata.
- Stampanti Phomemo M110, NIIMBOT B21 Pro e HaccpOK Print: nessun driver verificato o test hardware.

## Compilazione cloud
1. Crea un repository GitHub e carica il contenuto di questo archivio mantenendo i percorsi.
2. Apri Actions e avvia `Build Etichetta Facile APK`.
3. Se la build riesce, scarica l'artifact `etichetta-facile-debug-apk`.
4. Il risultato è un APK debug, non una release firmata per distribuzione.

Questa base è intenzionalmente prudente: non dichiarare funzionante alcuna funzione prima di averla provata sul telefono.
