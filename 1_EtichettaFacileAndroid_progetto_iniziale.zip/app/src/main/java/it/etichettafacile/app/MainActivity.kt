package it.etichettafacile.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.room.withTransaction
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import it.etichettafacile.app.data.AppDatabase
import it.etichettafacile.app.data.ProductLabel
import it.etichettafacile.app.ocr.ConservativeParser
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent {
            MaterialTheme {
                var product by remember { mutableStateOf("") }
                var brand by remember { mutableStateOf("") }
                var lot by remember { mutableStateOf("") }
                var expiry by remember { mutableStateOf("") }
                var ingredients by remember { mutableStateOf("") }
                var opening by remember { mutableStateOf("") }
                var storage by remember { mutableStateOf("Seguire le indicazioni in etichetta") }
                var photoUri by remember { mutableStateOf<Uri?>(null) }
                var rawOcr by remember { mutableStateOf("") }
                var status by remember { mutableStateOf("Pronto") }
                var selectedMode by remember { mutableStateOf("Entrambe") }
                val history by db.labels().all().collectAsState(initial = emptyList())
                val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
                    if (uri != null) {
                        photoUri = uri
                        status = "Foto importata. Avvio OCR…"
                        try {
                            val image = InputImage.fromFilePath(this, uri)
                            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                                .addOnSuccessListener { result ->
                                    rawOcr = result.text
                                    val fields = ConservativeParser.parse(result.text)
                                    if (lot.isBlank()) lot = fields.lot
                                    if (expiry.isBlank()) expiry = fields.expiry
                                    if (brand.isBlank()) brand = fields.brand
                                    if (ingredients.isBlank()) ingredients = fields.ingredients
                                    if (product.isBlank()) product = result.text.lines().firstOrNull().orEmpty().take(80)
                                    status = "OCR completato: controlla e correggi i campi."
                                }
                                .addOnFailureListener { status = "OCR non riuscito: puoi inserire i dati manualmente." }
                        } catch (_: Exception) {
                            status = "Foto importata; OCR non riuscito. Compila i campi manualmente."
                        }
                    }
                }
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Etichetta Facile", style = MaterialTheme.typography.headlineMedium)
                    Text("Prototipo Android • controlla sempre i dati prima della stampa")
                    Button(onClick = { photoPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("Importa foto etichetta originale") }
                    Text("La foto è selezionata dal telefono; il salvataggio permanente dell'immagine originale va completato e verificato prima dell'uso operativo.")
                    OutlinedTextField(product, { product = it }, label = { Text("Prodotto") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(brand, { brand = it }, label = { Text("Produttore / marca") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(lot, { lot = it }, label = { Text("Lotto") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(expiry, { expiry = it }, label = { Text("Scadenza originale") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(ingredients, { ingredients = it }, label = { Text("Ingredienti / allergeni da verificare") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    OutlinedTextField(opening, { opening = it }, label = { Text("Data di apertura") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(storage, { storage = it }, label = { Text("Conservazione") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(rawOcr, { rawOcr = it }, label = { Text("Testo OCR completo (modificabile)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                    Text("Cosa stampare")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Originale", "Operativa", "Entrambe").forEach { option ->
                            FilterChip(selected = selectedMode == option, onClick = { selectedMode = option }, label = { Text(option) })
                        }
                    }
                    Button(onClick = {
                        lifecycleScope.launch {
                            db.labels().save(ProductLabel(
                                productName = product, brand = brand, lot = lot, expiry = expiry,
                                ingredients = ingredients, openingDate = opening, storage = storage,
                                originalPhotoUri = photoUri?.toString().orEmpty(), rawOcrText = rawOcr
                            ))
                            status = "Scheda salvata nella cronologia locale."
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Salva nella cronologia") }
                    Text(status)
                    Divider()
                    Text("Cronologia locale (${history.size})", style = MaterialTheme.typography.titleLarge)
                    history.forEach { item ->
                        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(item.productName.ifBlank { "Prodotto senza nome" }, style = MaterialTheme.typography.titleMedium)
                                Text("Lotto: ${item.lot.ifBlank { "—" }} • Scadenza: ${item.expiry.ifBlank { "—" }}")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = {
                                        product = item.productName; brand = item.brand; lot = item.lot; expiry = item.expiry
                                        ingredients = item.ingredients; opening = item.openingDate; storage = item.storage
                                        rawOcr = item.rawOcrText
                                        photoUri = item.originalPhotoUri.takeIf { it.isNotBlank() }?.let(Uri::parse)
                                        status = "Scheda caricata per modifica."
                                    }) { Text("Apri / modifica") }
                                    TextButton(onClick = { lifecycleScope.launch { db.labels().delete(item.id); status = "Scheda eliminata." } }) { Text("Elimina") }
                                }
                            }
                        }
                    }
                    Text("Stampanti: nessuna integrazione Bluetooth dichiarata verificata. La stampa diretta sarà aggiunta solo dopo test reali.")
                    Text("Modalità selezionata: $selectedMode. Stampa non ancora collegata in questa versione.")
                }
            }
        }
    }
}
